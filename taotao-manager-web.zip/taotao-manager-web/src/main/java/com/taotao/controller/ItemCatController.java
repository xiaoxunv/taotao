package com.taotao.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.taotao.common.pojo.EasyUITreeNode;
import com.taotao.service.ItemCatService;

/**
 * 商品分类管理Controller
 * 
 * @author yuexiaowei
 *
 */
@Controller
public class ItemCatController {
	@Autowired
	private ItemCatService itemCatService;

	@RequestMapping("/item/cat/list")
	@ResponseBody
	/*
	 * 这里面是不是应该有参数啊，什么参数？应该有个id，如果你展开这个节点的时候下面
	 * 没有子节点，他会发送一次请求，请求的时候会带上一个参数，就是当前节点的id，参数名是id吧，我们要接受这个id
	 * 接收完了之后，这个id应该是个parentId。parentId跟id是不是对不上，对不上的话你还能取到吗？
	 * 娶不到你可以使用一个注解@ReqeustParam
	 * 这里面还要注意，如果第一次请求，第一次请求并没有展开节点是不是，他这个id请求的时候并没有带参数是不是
	 * 那我应该给他默认值，defaultValue=0
	 */
	public List getItemCatList(@RequestParam(name = "id", defaultValue = "0") Long parentId) {
		List<EasyUITreeNode> itemCatList = itemCatService.getItemCatList(parentId);
		return itemCatList;
	}
}
