package com.taotao.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 页面展示Controller
 * @author yuexiaowei
 *
 */
@Controller
public class PageController {
	/*
	 * 这里面应该怎么写啊？现在我们要访问首页，你应该访问，比如你要访问一个域名的话，就应该是
	 * www.taotao.com,是不是就应该访问到这个首页了，就不要带什么工程名了，带其他的什么后缀，
	 * 是不是能直接访问到。那么这时候拦截形式应该是什么？ “/”
	 */
	@RequestMapping("/")
	public String showIndex(){
		return "index";
	}
	
	//你请求什么，我就给你响应什么
	@RequestMapping("{page}")
	public String showPage(@PathVariable String page){
		
		return page;
	}
}
