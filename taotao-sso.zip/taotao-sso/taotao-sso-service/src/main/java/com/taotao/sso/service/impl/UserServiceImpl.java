package com.taotao.sso.service.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import com.taotao.common.pojo.TaotaoResult;
import com.taotao.common.utils.JsonUtils;
import com.taotao.jedis.JedisClient;
import com.taotao.mapper.TbUserMapper;
import com.taotao.pojo.TbUser;
import com.taotao.pojo.TbUserExample;
import com.taotao.pojo.TbUserExample.Criteria;
import com.taotao.sso.service.UserService;

/**
 * 用户处理service
 * 
 * @author yuexiaowei
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private TbUserMapper userMapper;

	@Autowired
	private JedisClient jedisClient;

	@Value("${USER_SESSION}")
	private String USER_SESSION;
	@Value("${SESSION_EXPIRE}")
	private Integer SESSION_EXPIRE;

	@Override
	public TaotaoResult checkData(String data, int type) {
		// TODO Auto-generated method stub
		TbUserExample example = new TbUserExample();
		Criteria criteria = example.createCriteria();
		// 设置查询条件
		// 判断用户名是否可用
		if (type == 1) {
			criteria.andUsernameEqualTo(data);
			// 判断手机号是否可用
		} else if (type == 2) {
			criteria.andPhoneEqualTo(data);
			// 判断邮箱是否可用
		} else if (type == 3) {
			criteria.andEmailEqualTo(data);
		} else {
			return TaotaoResult.build(400, "参数中包含非法数据");
		}
		// 执行查询
		List<TbUser> list = userMapper.selectByExample(example);

		if (list != null && list.size() > 0) {
			// 查询到数据，返回false
			return TaotaoResult.ok(false);
		}
		// 数据可以使用
		return TaotaoResult.ok(true);
	}

	@Override
	public TaotaoResult register(TbUser tbUser) {
		// TODO Auto-generated method stub

		// 判断用户名是否为空
		if (StringUtils.isBlank(tbUser.getUsername())) {
			return TaotaoResult.build(400, "用户名不能为空！");
		}
		// 判断用户名是否重复
		TaotaoResult result = checkData(tbUser.getUsername(), 1);
		if (!(boolean) result.getData()) {
			return TaotaoResult.build(400, "用户名重复！");
		}

		// 判断密码是否为空
		if (!StringUtils.isNotBlank(tbUser.getPassword())) {
			return TaotaoResult.build(400, "密码不能为空！");
		}

		// 判断手机号
		if (StringUtils.isNoneBlank(tbUser.getPhone())) {

			// 是否重复校验
			TaotaoResult resultPhone = checkData(tbUser.getPhone(), 2);
			if (!(boolean) resultPhone.getData()) {
				return TaotaoResult.build(400, "电话号码重复！");
			}

		}

		// 判断邮箱
		if (StringUtils.isNoneBlank(tbUser.getEmail())) {

			// 是否重复校验
			TaotaoResult resultEmail = checkData(tbUser.getEmail(), 3);
			if (!(boolean) resultEmail.getData()) {
				return TaotaoResult.build(400, "email重复！");
			}

		}

		// 补全pojo的属性
		tbUser.setCreated(new Date());
		tbUser.setUpdated(new Date());

		// 密码要进行MD5加密
		String md5DigestAsHex = DigestUtils.md5DigestAsHex(tbUser.getPassword().getBytes());
		tbUser.setPassword(md5DigestAsHex);
		userMapper.insert(tbUser);
		// 返回注册成功
		return TaotaoResult.ok();

	}

	@Override
	public TaotaoResult login(String username, String password) {
		// TODO Auto-generated method stub
		TbUserExample example = new TbUserExample();
		List<TbUser> userList = userMapper.selectByExample(example);
		if (userList == null && userList.size() == 0) {
			// 这里提示模糊一点也没问题
			TaotaoResult.build(400, "用户名或密码错误！");
		}

		TbUser user = userList.get(0);
		//密码要进行md5加密然后再校验
		if (!DigestUtils.md5DigestAsHex(password.getBytes()).equals(user.getPassword())) {
			//返回登录失败
			TaotaoResult.build(400, "用户名或密码错误！");
		}
		// 生成token，使用uuid
		String token = UUID.randomUUID().toString();
		// 清空密码
		user.setPassword(null);
		// 把用户信息保存到redis，key就是token，value就是用户信息
		jedisClient.set(USER_SESSION + ":" + token, JsonUtils.objectToJson(user));
		// 设置key的过期时间
		jedisClient.expire(USER_SESSION + ":" + token, SESSION_EXPIRE);
		// 返回登陆成功，其中要把token返回
		return TaotaoResult.ok(token);
	}

	@Override
	public TaotaoResult getUserByToken(String token) {
		// TODO Auto-generated method stub
		String json = jedisClient.get(USER_SESSION+":"+token);
		if(StringUtils.isBlank(json)){
			return TaotaoResult.build(400, "用户登陆已过期");
			
		}
		//重置session的过期时间
		jedisClient.expire(USER_SESSION+":"+token, SESSION_EXPIRE);
		//把json转换成User对象
		TbUser tbUser = JsonUtils.jsonToPojo(json, TbUser.class);
		//观察返回下面两种类型有什么不同
		return TaotaoResult.ok(tbUser);
		//return TaotaoResult.ok(json);
	}

}
