package com.taotao.jedis;

public interface JedisClient {
/*
 * 单机版和集群版用到了一个JedisPool和JedisCluster，那么这两个是不是在spring容器中存在的，等我编好了之后
 * 你给我注入一个对象就好了，那么这时候需要在spring中配置这个一个对象
 */
	String set(String key, String value);
	String get(String key);
	Boolean exists(String key);
	Long expire(String key, int seconds);
	Long ttl(String key);
	Long incr(String key);
	Long hset(String key, String field, String value);
	String hget(String key, String field);
	Long hdel(String key, String... field);
}
