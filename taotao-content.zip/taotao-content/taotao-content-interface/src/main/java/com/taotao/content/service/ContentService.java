package com.taotao.content.service;

import java.util.List;

import com.taotao.common.pojo.TaotaoResult;
import com.taotao.pojo.TbContent;

public interface ContentService {

	public TaotaoResult addContent(TbContent content);
	
	public List<TbContent> getContentByCid(long cid);
}
