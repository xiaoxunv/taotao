package com.taotao.activemq;

import java.io.IOException;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpringActivemq {

	@Test
	public void testSpringActivemq() throws IOException{
		//初始化spring容器
		ApplicationContext ac=new ClassPathXmlApplicationContext("classpath:spring/applicationContext-activemq.xml");
		//等待
		/*
		 * 这里为什么要等待，不太明白
		 */
		//System.in.read();
	}
}
