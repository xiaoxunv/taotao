package com.taotao.solrJ;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.junit.Test;

public class TestSolrJ {

	
	/**
	 * 更新就是添加，没有更新方法，更新的时候先找到id对应的文档，删掉，删掉之后再添加一个新的。
	 * @throws SolrServerException
	 * @throws IOException
	 */
	//@Test
	public void testSolrJ() throws SolrServerException, IOException{
		//这是客户端，solr是服务端
		/*
		 * 1、创建一个SolrServer对象，创建一个HttpSolrServer对象
		 * 2、需要指定solr服务的url
		 * 3、创建一个文档对象SolrInputDocument
		 * 4、向文档中添加域，必须有id域，域的名称必须在schema.xml中定义
		 * 5、把文档对象写入索引库
		 * 6、提交
		 */
		//这个url就是solr服务的地址
		SolrServer solrServer = new HttpSolrServer("http://106.12.208.224/solr/collection1");
		SolrInputDocument document = new SolrInputDocument();
		document.addField("id", "test002");
		document.addField("item_title", "测试商品2");
		document.addField("item_price", 1000);
		solrServer.add(document);
		solrServer.commit();
	}
	
	//测试删除
	//@Test
	public void testDeleteDocumentById() throws SolrServerException, IOException{
		SolrServer solrServer = new HttpSolrServer("http://106.12.208.224/solr/collection1");
		solrServer.deleteById("test001");
		
		//提交
		solrServer.commit();
	}
	
	/**
	 * 根据查询删除
	 * @throws SolrServerException
	 * @throws IOException
	 */
	//@Test
	public void testDeleteDocumentByQuery() throws SolrServerException, IOException{
		SolrServer solrServer = new HttpSolrServer("http://106.12.208.224/solr/collection1");
		//在id这个域上，查询id=123的
		solrServer.deleteByQuery("id:123");
		//提交
		solrServer.commit();
	}
	
	public void testQuery() throws IOException, SolrServerException{
		//创建一个SolrServer对象
		SolrServer solrServer = new HttpSolrServer("http://106.12.208.224/solr/collection1");
		//创建一个SolrQuery对象
		SolrQuery query = new SolrQuery();
		//设置查询条件、过滤条件、分页条件、排序条件、高亮
		//query.set("q","*:*");这行代码等价于下面这一行
		query.setQuery("手机");
		//分页条件
		query.setStart(30);
		query.setRows(20);
		//设置默认搜索域
		query.set("df", "item_words");
		//设置高亮
		query.setHighlight(true);
		//高亮显示的域
		query.addHighlightField("item_title");
		query.setHighlightSimplePre("<div>");
		query.setHighlightSimplePost("</div>");
		
		
		//执行查询，得到一个Response对象
		QueryResponse response = solrServer.query(query);
		//去查询结果
		SolrDocumentList results = response.getResults();
		//去查询结果总记录数
		System.out.println("查询结果总记录数："+results.getNumFound());
		for (SolrDocument solrDocument : results) {
			System.out.println(solrDocument.get("id"));
			//去高亮显示map套map再套list
			Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();
			
			List<String> list = highlighting.get(solrDocument.get("id")).get("item_title");
			String itemTitle="";
			if(list!=null && list.size()>0){
				itemTitle = list.get(0);
			}else{
				/*
				 * 没值，你也不能说显示个空串、商品标题原来不是有标题吗，只是说没有高亮的结果
				 * 没有高亮的结果，是不是应该去原来的内容
				 */
				itemTitle=(String) solrDocument.get("item_title");
			}
			
			System.out.println(itemTitle);
			System.out.println(solrDocument.get("item_sell_point"));
			System.out.println(solrDocument.get("item_price"));
			System.out.println(solrDocument.get("item_image"));
			System.out.println(solrDocument.get("item_category_name"));
			System.out.println("=======================================");
		}
		
		
		
		
	}
}
