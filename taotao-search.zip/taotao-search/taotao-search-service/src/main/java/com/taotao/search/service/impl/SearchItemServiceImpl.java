package com.taotao.search.service.impl;

import java.util.List;

import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.common.SolrInputDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taotao.common.pojo.SearchItem;
import com.taotao.common.pojo.TaotaoResult;
import com.taotao.search.mapper.SearchItemMapper;
import com.taotao.search.service.SearchItemService;

/**
 * 商品数据导入索引库
 * @author yuexiaowei
 *
 */
@Service
public class SearchItemServiceImpl implements SearchItemService {

	
	@Autowired
	private SearchItemMapper searchItemMapper;
	
	@Autowired
	private SolrServer solrServer;
	
	@Override
	public TaotaoResult importItemsToIndex() {
		
		try {
			//1、先查询所有商品数据
			/*
			 * 查询商品数据，调mapper(dao)，注入SearchItemMapper,注入进来是可以，但是前提你得有这个对象
			 * 你要是想有这个对象怎么办？扫描。有的同学说直接用，它是一个接口你怎么直接用呢？你得拿到他的代理对象，代理对象你得使用
			 * sqlSessionFactory创建，sqlSessionFactory配置到spring容器里面了，让spring容器帮我们创建
			 * 这个对象，创建代理对象，包扫描器
			 */
			List<SearchItem> itemList = searchItemMapper.getItemList();
			//2、遍历商品数据添加到索引库
			for (SearchItem searchItem : itemList) {
				//创建文档对象
				SolrInputDocument document = new SolrInputDocument();
				//想文档中添加域
				document.addField("id", searchItem.getId());
				document.addField("item_title", searchItem.getTitle());
				document.addField("item_sell_point", searchItem.getSell_point());
				document.addField("item_price", searchItem.getPrice());
				document.addField("item_image", searchItem.getImage());
				document.addField("item_category_name", searchItem.getCategory_name());
				//document.addField("id", searchItem.getId());
				document.addField("item_desc", searchItem.getItem_desc());
				//把文档写入索引库
				solrServer.add(document);
			}
			//3、提交
			solrServer.commit();
			//4、返回添加成功
		} catch (Exception e) {
			e.printStackTrace();
			return TaotaoResult.build(500, "导入数据失败");
		}
		
		
		return TaotaoResult.ok();
	}

}
