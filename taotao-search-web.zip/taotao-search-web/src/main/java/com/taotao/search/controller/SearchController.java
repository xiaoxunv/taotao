package com.taotao.search.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.taotao.common.pojo.SearchResult;
import com.taotao.search.service.SearchService;

/**
 * 搜索服务Controller
 * 
 * @author yuexiaowei
 *
 */

@Controller
public class SearchController {

	@Autowired
	private SearchService searchService;

	@Value("${SEARCH_RESULT_ROWS}")
	private Integer SEARCH_RESULT_ROWS;

	@RequestMapping("/search")
	public String search(@RequestParam("q") String queryString, @RequestParam(defaultValue = "1") Integer page,Model model) {

		/*
		 * rows这个参数应该写到配置文件里，写死了不太合适，写死了之后，你之后要改一下每页显示多少条记录，是不是得改代码，所所以
		 * 应该放到配置文件里
		 */
		/*
		 * 这里得try	catch了，如果再往外抛的话，就抛给用户了，肯定不合适吧
		 */
		try {
			//解决get乱码问题
			queryString=new String(queryString.getBytes("ISO8859-1"), "UTF-8");
			
			SearchResult searchResult=searchService.search(queryString, page, SEARCH_RESULT_ROWS);
			//把结果传递给页面
			model.addAttribute("totalPages", searchResult.getTotalPages());
			model.addAttribute("itemList", searchResult.getItemList());
			model.addAttribute("query", queryString);
			model.addAttribute("page", page);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//返回逻辑视图
		return "search";

	}
}
