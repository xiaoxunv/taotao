package com.taotao.pagehelper;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.taotao.mapper.TbItemMapper;
import com.taotao.pojo.TbItem;
import com.taotao.pojo.TbItemExample;

public class TestPageHelper {
	/*
	 * 1、在mybatis的配置文件中配置分页插件 2、在执行查询之前配置分页条件，使用PageHelper的静态方法 3、执行查询
	 * 4、去分页信息，使用PageHelper对象取
	 */
	@Test
	public void testPageHelper() {
		PageHelper.startPage(1, 10);
		ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		TbItemMapper itemMapper = ac.getBean(TbItemMapper.class);
		TbItemExample example = new TbItemExample();
		// Criteria criteria = example.createCriteria();
		List<TbItem> list = itemMapper.selectByExample(example);

		PageInfo<TbItem> pageInfo = new PageInfo<>(list);
		System.out.println("总记录数：" + pageInfo.getTotal());
		System.out.println("总页数：" + pageInfo.getPages());
		System.out.println("返回的记录数：" + list.size());

	}

	/*
	 * 这里为什么注视到@Test，因为下面这些数据我以前已经插过一遍，所以再插入的话就会报主键重复，所以把它注释掉，不让执行
	 */
	//@Test
	public void testAddItem() {
		ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		TbItemMapper itemMapper = ac.getBean(TbItemMapper.class);
		for (long i = 150000; i < 155000; i++) {
			System.out.println("开始时间"+System.currentTimeMillis());
			TbItem tbItem = new TbItem();
			tbItem.setId(i);
			tbItem.setBarcode("123456789");
			tbItem.setCid(560L);
			tbItem.setCreated(new Date());
			tbItem.setImage("http://192.168.25.133/group1/M00/00/00/wKgZhVuHlPKAV1TpAJc_Zdq8KZU711.jpg,http://192.168.25.133/group1/M00/00/00/wKgZhVuHlSCAK21ZAJc_Zdq8KZU713.jpg,http://192.168.25.133/group1/M00/00/00/wKgZhVuHlXqAU8w2AJc_Zdq8KZU787.jpg");
			tbItem.setNum(1);
			tbItem.setPrice(Long.valueOf("123"));
			tbItem.setSellPoint("下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！"
					+ "下单送12000毫安移动电源！双3.5英寸魔焕炫屏，以非凡视野纵观天下时局，尊崇翻盖设计，张弛中，尽显从容气度！");
			tbItem.setStatus(new Byte("0".toString()));
			tbItem.setTitle("测试标题");
			tbItem.setUpdated(new Date());
			itemMapper.insert(tbItem);
			System.out.println("结束时间"+System.currentTimeMillis());
		}
	}
}
